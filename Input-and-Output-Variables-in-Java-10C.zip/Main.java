class Main {
  public static void main(String[] args) {
    System.out.println("I am learning Java!");
  }
}
/*this is Wecome-Potato on Replit*/
/*Java variables type
there are 5 types of variables
boolean:true or false,  only used to state true or false
integers: Int, to represent WHOLE numbers
strings: text, ex "Hello"
float: Decimls, ex 3.14159
char:Single characters, "a", "b", "c", etc
write a code that gives you how many characters are in "pneumonoultramicroscopicsilicovolcanoconiosis"

in math you say x=4 which means that 4=x
in programing x=4 which means x is assigned x

x = "patty"
b = "tomato"
c = "cheese"
d = "Bread"
e = "lettuce"
f = "ketchup"

the template is: type variable = Value;
*/